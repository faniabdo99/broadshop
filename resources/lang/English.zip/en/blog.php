<?php
return [
    //Blog Index
    'page_title' => 'Blog',
    //Single Blog
    
];