<?php
    return[
        //Parts
        'email_address' => 'Email Address',
        'subscribe' => 'Subscribe',
        //Notofications
        'success' => 'Success',
        'error' => 'Error'
    ];