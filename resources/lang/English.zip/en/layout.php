<?php
 return [
    //Footer
    'cookies_disclaimer_title' => 'This site uses cookies to enhance your user experince',
    'cookies_disclaimer_cta' => 'Agree',
    'about_us' => 'We have many distinctive products such as sports equipment and lighting items. Discover in our store products that meet all your needs',
    'quick_links' => 'Quick Links',
    'kugoo_scooters' => 'KUGOO Scooters',
    'about' => 'About Broadshop',
    'shop' => 'Shop',
    'blog' => 'Blog',
    'contact' => 'Contact us',
    'address' => 'Address',
    'copywrites' => 'Copyright ©2021 Broadshop. All Rights Reserved.',
    //Navbar
    'navbar_free_shipping' => 'FREE shipping for orders above 50€',
    'wishlist' => 'My Wishlist',
    'welcome' => 'Welcome',
    'logout' => 'Logout',
    'signin' => 'Signin',
    'cart' => 'Cart',
    'cart_empty' => 'There is no items in your cart yet.',
    'subtotal' => 'Subtotal',
    'view_cart' => 'View Cart',
    'checkout' => 'Checkout',
    'home' => 'Home',

];