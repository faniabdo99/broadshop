<?php
    return[
        //Newsletter
        'newsletter_title' => 'Be the first and get weekly updates',
        
    ];